<?php
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/

/**
 * Plugin Name: Google Calendar Event
 * Description: create custom google calendar events.
 * Version: 1.0.0
 * Author: Finegap
 * Author URI: https://finegap.com
 * Text Domain: Google Calendar
 */

// Exit if accessed directly

//defined('ABSPATH') || exit;

ini_set('memory_limit', '-1');
ini_set('max_execution_time', '-1');
ini_set('display_errors', 1);

/**
 *  update google code
 */
//add_action('wp_footer', 'create_google_calendar_events');
$credentials = __DIR__ . '/credentials.json';
require __DIR__ . '/vendor/autoload.php';

$client = new Google_Client();
$client->setApplicationName('testoo');
$client->setScopes(array(Google_Service_Calendar::CALENDAR));
$client->setAuthConfig($credentials);
$client->setAccessType('offline');
$client->getAccessToken();
$client->getRefreshToken();

$service = new Google_Service_Calendar($client);

$event   = new Google_Service_Calendar_Event(array(
    'summary' => 'testing222233',
    'location' => 'lucknow',
    'description' => 'A chance to hear more about Google\'s developer products.',
    'start' => array(
        'date' => '2023-02-18',
        'timeZone' => 'America/Los_Angeles',
    ),
    'end' => array(
        'date' => '2023-02-18',
        'timeZone' => 'America/Los_Angeles',
    ),
    'recurrence' => array(
        'RRULE:FREQ=DAILY;COUNT=1'
    ),
    'attendees' => array(),
    'reminders' => array(
        'useDefault' => FALSE,
        'overrides' => array(
            array('method' => 'email', 'minutes' => 24 * 60),
            array('method' => 'popup', 'minutes' => 10),
        ),
    ),
));

$calendarId = 'dheerajmaury017@gmail.com';
/*$event      = $service->events->insert($calendarId, $event);
print_r($event->id);*/
//$calenderId = "dheerajmaury017@gmail.com";
//$event = "6udjd65kesb3it6jnklf684frg";
//$temp = $service->events->delete($calendarId, $event);
//print_r($temp);

$event = "o0meqmqvpc8p0ch16dkv3jc83g";
$event = $service->events->get($calendarId, $event);

$event->setSummary('dddd5555111111');

$event->setStart(
    new Google_Service_Calendar_EventDateTime(['dateTime' => date("c", strtotime("2023-02-20")), 'timeZone' => 'Europe/Moscow'])
);

$event->setEnd(
    new Google_Service_Calendar_EventDateTime(['dateTime' => date("c", strtotime("2023-02-20")), 'timeZone' => 'Europe/Moscow'])
);

$event->setDescription('<table class="table">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
      </tr>
      <tr>
        <td>Mary</td>
        <td>Moe</td>
        <td>mary@example.com</td>
      </tr>
      <tr>
        <td>July</td>
        <td>Dooley</td>
        <td>july@example.com</td>
      </tr>
    </tbody>
  </table>');

$updatedEvent = $service->events->update($calendarId, $event->getId(), $event);

// Print the updated date.
echo $updatedEvent->getUpdated();
