<?php
/*$con = mysqli_connect('sql197.main-hosting.eu','u116890973_appselfiebox','&1mqhaF[wvW','u116890973_appselfiebox');
$id=$_POST['id'];
 $eventName=$_POST['eventName'];
 $eventDate=$_POST['eventDate'];
 $google_event_id=$_POST['google_event_id'];
*/
ini_set('memory_limit', '-1');
ini_set('max_execution_time', '-1');
ini_set('display_errors', 1);

/**
 *  update google code
 */
//add_action('wp_footer', 'create_google_calendar_events');
$credentials = __DIR__ . '/credentials.json';
require __DIR__ . '/vendor/autoload.php';

$client = new Google_Client();
$client->setApplicationName('testoo');
$client->setScopes(array(Google_Service_Calendar::CALENDAR));
$client->setAuthConfig($credentials);
$client->setAccessType('offline');
$client->getAccessToken();
$client->getRefreshToken();

$service = new Google_Service_Calendar($client);

$event   = new Google_Service_Calendar_Event(array(
    'summary' => 'testing222233',
    'location' => '800 Howard St., San Francisco, CA 94103',
    'description' => 'A chance to hear more about Google\'s developer products.',
    'start' => array(
        'date' => '2023-02-17',
        'timeZone' => 'America/Los_Angeles',
    ),
    'end' => array(
        'date' => '2023-02-17',
        'timeZone' => 'America/Los_Angeles',
    ),
    'recurrence' => array(
        'RRULE:FREQ=DAILY;COUNT=1'
    ),
    'attendees' => array(),
    'reminders' => array(
        'useDefault' => FALSE,
        'overrides' => array(
            array('method' => 'email', 'minutes' => 24 * 60),
            array('method' => 'popup', 'minutes' => 10),
        ),
    ),
));
/*
//-----------get calender id from DB--------------------
$sql = "SELECT * FROM `keys` WHERE key_name='canlender_id'";;

$fetch = mysqli_query($con,$sql);
if($fetch){
$row = mysqli_fetch_assoc($fetch);
$calendarId=$row['key'];
}
//------------------------end----------------------------
*/
$calendarId = '04bdf08b42ea46c5194fcb52f67593b479d68bef1f6296c288be3d8cc9235d14@group.calendar.google.com';
//------------insert event-----------------------
/*$event      = $service->events->insert($calendarId, $event);
print_r($event->id);*/

//-----------------------delete event-----------------
//$calenderId = "dheerajmaury017@gmail.com";
//$event = "6udjd65kesb3it6jnklf684frg";
//$temp = $service->events->delete($calendarId, $event);
//print_r($temp);

//-------------------------Update event-----------------------------------
$event = $google_event_id;
$event = $service->events->get($calendarId, $event);

$start = new Google_Service_Calendar_EventDateTime();
if ($event_start) {
    $start->setDateTime($eventDate . 'T' . $event_start . ':00');
} else {
    $start->setDate($eventDate);
}
$start->setTimeZone("Asia/Kolkata");
$event->setStart($start);


$end = new Google_Service_Calendar_EventDateTime();
//if ($event_start) {
if (!$event_end) {
    $event_end = date('H:i', strtotime('+01 minutes', strtotime($event_start)));
}
$end->setDateTime($eventDate . 'T' . $event_end . ':00');
//} else {
// $end->setDate($eventDate);
//}

$end->setTimeZone("Asia/Kolkata");
$event->setEnd($end);
$event->setSummary("Event Name");
$event->setDescription("EVENT Description");
$event->setcolorId("2");
$updatedEvent = $service->events->update($calendarId, $event->getId(), $event);

// Print the updated date.
//echo $updatedEvent->getUpdated();
